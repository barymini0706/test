﻿using System;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // 1. 18歲以上 (radioButton5) 選擇時的事件
            radioButton5.CheckedChanged += RadioButton5_CheckedChanged;
            radioButton1.CheckedChanged += AgeOther_CheckedChanged;
            radioButton2.CheckedChanged += AgeOther_CheckedChanged;
            radioButton3.CheckedChanged += AgeOther_CheckedChanged;
            radioButton4.CheckedChanged += AgeOther_CheckedChanged;

            // 2. 3C時數選擇「不使用」(radioButton6) 時，活動選項與備註設為 false
            radioButton6.CheckedChanged += radioButton6_CheckedChanged;
            radioButton7.CheckedChanged += TimeOther_CheckedChanged;
            radioButton8.CheckedChanged += TimeOther_CheckedChanged;
            radioButton9.CheckedChanged += TimeOther_CheckedChanged;
            radioButton10.CheckedChanged += TimeOther_CheckedChanged;
        }

        private void RadioButton5_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton5.Checked)
            {
                groupBox2.Enabled = false;
                groupBox3.Enabled = false;
                textBox1.Enabled = false;
            }
        }

        private void AgeOther_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            if (rb != null && rb.Checked)
            {
                groupBox2.Enabled = true;
                if (!radioButton6.Checked)
                {
                    groupBox3.Enabled = true;
                    textBox1.Enabled = true;
                }
            }
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton6.Checked)
            {
                groupBox3.Enabled = false;
                textBox1.Enabled = false;
            }
        }

        private void TimeOther_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            if (rb != null && rb.Checked)
            {
                if (!radioButton5.Checked)
                {
                    groupBox3.Enabled = true;
                    textBox1.Enabled = true;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string result = "";

            if (radioButton1.Checked) result += "受訪對象年齡：6歲以下\n";
            else if (radioButton2.Checked) result += "受訪對象年齡：6~10\n";
            else if (radioButton3.Checked) result += "受訪對象年齡：10~14\n";
            else if (radioButton4.Checked) result += "受訪對象年齡：14~18\n";
            else if (radioButton5.Checked)
            {
                result += "受訪對象年齡：18歲以上\n";
                MessageBox.Show(result, "問卷結果", MessageBoxButtons.OK, MessageBoxIcon.None);
                return;
            }

            result += "每日使用3C產品時數：\n";
            if (radioButton6.Checked)
            {
                result += "不使用\n";
                MessageBox.Show(result, "問卷結果", MessageBoxButtons.OK, MessageBoxIcon.None);
                return;
            }
            else if (radioButton7.Checked) result += "二小時以內\n";
            else if (radioButton8.Checked) result += "二～四小時\n";
            else if (radioButton9.Checked) result += "四～六小時\n";
            else if (radioButton10.Checked) result += "六小時以上\n";

            result += "3C產品的使用行為：\n";
            if (checkBox1.Checked) result += checkBox1.Text + "\n";
            if (checkBox2.Checked) result += checkBox2.Text + "\n";
            if (checkBox3.Checked) result += checkBox3.Text + "\n";
            if (checkBox4.Checked) result += checkBox4.Text + "\n";

            if (!string.IsNullOrWhiteSpace(textBox1.Text))
            {
                result += "備註：" + textBox1.Text + "\n";
            }

            MessageBox.Show(result, "問卷結果", MessageBoxButtons.OK, MessageBoxIcon.None);
        }

        // 補上缺少的事件方法以消除編譯錯誤
        private void radioButton1_CheckedChanged(object sender, EventArgs e) { }
        private void groupBox2_Enter(object sender, EventArgs e) { }
        private void checkBox2_CheckedChanged(object sender, EventArgs e) { }
    }
}