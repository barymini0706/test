﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double height = double.Parse(textBox1.Text);
                double weight = double.Parse(textBox2.Text);

                // 判斷如果勾選的是「公分」，才需要除以 100 換算成公尺
                if (radioButton1.Checked)
                {
                    height = height / 100.0;
                }
                // 如果勾選的是「公尺」(radioButton2)，就維持原本的公尺數值不變

                double bmi = weight / (height * height);

                string eval = "";
                if (bmi < 18.5)
                {
                    eval = "體重過輕";
                }
                else if (bmi >= 18.5 && bmi < 24)
                {
                    eval = "健康體重";
                }
                else if (bmi >= 24 && bmi < 27)
                {
                    eval = "體重過重";
                }
                else
                {
                    eval = "肥胖";
                }

                label3.Text = $"BMI值：{bmi:F1} BMI評等：{eval}";
            }
            catch (FormatException)
            {
                MessageBox.Show("請輸入有效的數字！", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
}
}

